<?php
/*
Plugin Name: WooCommerce Gift Option
Plugin URI: https://github.com/childtheme/uncode
Description: Adds a 'Is this order a gift?' checkbox to the WooCommerce checkout page.
Version: 1.0
Author: Dmitrii Chempalov
Author URI: https://github.com/childtheme/uncode
License: GPL2
Text Domain: woocommerce-gift-option
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Add a custom checkbox field to the checkout page
function wgo_add_gift_checkbox_to_checkout( $checkout ) {
    echo '<div id="gift_checkbox_field"><h3>' . __( 'Gift Options', 'woocommerce-gift-option' ) . '</h3>';

    woocommerce_form_field( 'is_gift', array(
        'type'          => 'checkbox',
        'class'         => array('form-row-wide'),
        'label'         => __( 'This order is a gift', 'woocommerce-gift-option' ),
    ), $checkout->get_value( 'is_gift' ));

    echo '</div>';
}
add_action( 'woocommerce_after_order_notes', 'wgo_add_gift_checkbox_to_checkout' );

// Process the checkout and save the custom field
function wgo_save_gift_checkbox_field( $order_id ) {
    if ( isset( $_POST['is_gift'] ) ) {
        update_post_meta( $order_id, '_is_gift', 'yes' );
    } else {
        update_post_meta( $order_id, '_is_gift', 'no' );
    }
}
add_action( 'woocommerce_checkout_update_order_meta', 'wgo_save_gift_checkbox_field' );

// Display the custom field value in the admin order meta
function wgo_display_gift_checkbox_in_admin_order_meta( $order ) {
    $is_gift = get_post_meta( $order->get_id(), '_is_gift', true );

    echo '<p><strong>' . __( 'Is this order a gift?', 'woocommerce-gift-option' ) . ':</strong> ' . ucfirst( esc_html( $is_gift ) ) . '</p>';
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'wgo_display_gift_checkbox_in_admin_order_meta', 10, 1 );

// Add the custom field to order emails
function wgo_add_gift_checkbox_to_order_emails( $fields, $sent_to_admin, $order ) {
    $is_gift = get_post_meta( $order->get_id(), '_is_gift', true );

    $fields['is_gift'] = array(
        'label' => __( 'Is this order a gift?', 'woocommerce-gift-option' ),
        'value' => ucfirst( esc_html( $is_gift ) ),
    );

    return $fields;
}
add_filter( 'woocommerce_email_order_meta_fields', 'wgo_add_gift_checkbox_to_order_emails', 10, 3 );

// Display the custom field in the order details page
function wgo_display_gift_checkbox_in_order_details( $order_id ) {
    $is_gift = get_post_meta( $order_id, '_is_gift', true );

    if ( $is_gift === 'yes' ) {
        echo '<p><strong>' . __( 'You marked this order as a gift.', 'woocommerce-gift-option' ) . '</strong></p>';
    }
}
add_action( 'woocommerce_thankyou', 'wgo_display_gift_checkbox_in_order_details', 20 );
add_action( 'woocommerce_view_order', 'wgo_display_gift_checkbox_in_order_details', 20 );
