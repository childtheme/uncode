<?php
/*
Plugin Name: Woolist Category Products
Description: Display WooCommerce products from a specific category with improved styles, display options, and a customizable title.
Version: 1.3
Author: Dmitrii CHempalov
*/

// Enqueue styles
function woolist_category_products_enqueue_styles() {
    wp_enqueue_style('woolist-category-products-style', plugin_dir_url(__FILE__) . 'css/style.css');
}
add_action('wp_enqueue_scripts', 'woolist_category_products_enqueue_styles');

// Create settings page
function woolist_category_products_settings_page() {
    add_options_page(
        'Woolist Category Products Settings',
        'Woolist Products Settings',
        'manage_options',
        'woolist-category-products',
        'woolist_category_products_settings_page_html'
    );
}
add_action('admin_menu', 'woolist_category_products_settings_page');

// Register settings
function woolist_category_products_register_settings() {
    register_setting('woolist_category_products_options', 'woolist_display_style');
}
add_action('admin_init', 'woolist_category_products_register_settings');

// Settings page HTML
function woolist_category_products_settings_page_html() {
    ?>
    <div class="wrap">
        <h1>Woolist Category Products Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('woolist_category_products_options'); ?>
            <?php do_settings_sections('woolist_category_products_options'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Display Style</th>
                    <td>
                        <select name="woolist_display_style">
                            <option value="grid" <?php selected(get_option('woolist_display_style'), 'grid'); ?>>Grid View</option>
                            <option value="list_titles" <?php selected(get_option('woolist_display_style'), 'list_titles'); ?>>List View (Titles Only)</option>
                            <option value="list_thumbnails" <?php selected(get_option('woolist_display_style'), 'list_thumbnails'); ?>>List View (Titles with Thumbnails)</option>
                        </select>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Shortcode function to display products from a specific category
function woolist_category_products_shortcode($atts) {
    // Attributes with default values
    $atts = shortcode_atts(array(
        'category' => '',
        'limit' => 12,
    ), $atts, 'woolist_category_products');

    if (empty($atts['category'])) return '<p>Please specify a category.</p>';

    // Get display style from settings
    $display_style = get_option('woolist_display_style', 'grid');

    // Get category title
    $category = get_term_by('slug', $atts['category'], 'product_cat');
    $category_title = $category ? '<h2 class="woolist-category-title">' . esc_html($category->name) . '</h2>' : '';

    // Query WooCommerce products from the specified category
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => intval($atts['limit']),
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => $atts['category'],
            ),
        ),
    );

    $loop = new WP_Query($args);
    if (!$loop->have_posts()) return '<p>No products found in this category.</p>';

    // Output HTML based on selected display style
    $output = $category_title;
    $output .= '<div class="woolist-category-products-grid ' . esc_attr($display_style) . '">';
    while ($loop->have_posts()) : $loop->the_post();
        global $product;

        if ($display_style == 'grid') {
            $output .= '<div class="woolist-product">';
            $output .= '<a href="' . get_permalink() . '">';
            $output .= woocommerce_get_product_thumbnail();
            $output .= '<h2 class="woolist-product-title">' . get_the_title() . '</h2>';
            $output .= '<span class="woolist-product-price">' . $product->get_price_html() . '</span>';
            $output .= '</a>';
            $output .= '</div>';
        } elseif ($display_style == 'list_titles') {
            $output .= '<div class="woolist-product-title-only">';
            $output .= '<h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>';
            $output .= '<span class="woolist-product-price">' . $product->get_price_html() . '</span>';
            $output .= '</div>';
        } elseif ($display_style == 'list_thumbnails') {
            $output .= '<div class="woolist-product-thumbnail-list">';
            $output .= '<a href="' . get_permalink() . '">';
            $output .= woocommerce_get_product_thumbnail();
            $output .= '<h2>' . get_the_title() . '</h2>';
            $output .= '</a>';
            $output .= '<span class="woolist-product-price">' . $product->get_price_html() . '</span>';
            $output .= '</div>';
        }
    endwhile;
    $output .= '</div>';

    wp_reset_postdata();
    return $output;
}
add_shortcode('woolist_category_products', 'woolist_category_products_shortcode');
